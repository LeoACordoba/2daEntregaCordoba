from setuptools import setup

setup(
    
    name= "paquete1",
    version= 1.0,
    description= "Probando el Primer paquete redistribuible",
    author= "Leonardo",
    author_email="leoocordoba@gmail.com",
    packages=["paquete1"],
    
)